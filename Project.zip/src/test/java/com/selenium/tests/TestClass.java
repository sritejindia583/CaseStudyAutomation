package com.selenium.tests;

class TestClass {
	public void testMethod() {
		System.out.println("Hello World");
	}
}
